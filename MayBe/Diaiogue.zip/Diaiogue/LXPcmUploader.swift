//
//  LXPcmUploader.swift
//  MayBe
//
//  Created by liuxiang on 2020/6/22.
//  Copyright © 2020 liuxiang. All rights reserved.
//

import UIKit

private let url = "https://192.168.5.3:8000/dialogues"

class PcmTask: NSObject{

    var data:Data?
    var hasUpload:Bool = false
    convenience  init(data:Data,hasUpload:Bool) {
        self.init()
        self.data = data
        self.hasUpload = hasUpload
    }
  
}

public enum PcmError:Swift.Error {
    
    case netError
    case serverError([String:Any])
}



public typealias PcmCompletion = (_  reslut:Result<[String:Any],PcmError>) -> Void



class LXPcmUploader: NSObject {
    
    var outputStream:OutputStream?
    var bodyStream:InputStream?
    var hasSpaceAvailable:Bool = false
    var isEnd:Bool = false
    var isStart:Bool = false
    var canWrite = false

    var timer:Timer?
    var dataTaskArr:[PcmTask] = [PcmTask]()
    var isWriting:Bool = false
    var alreadyRecord:Int64 = 0
    var alreadyUpload:Int64 = 0
    var completion:PcmCompletion?
    var loadRequest:UploadRequest?
    
    struct Streams {
           let input: InputStream
           let output: OutputStream
       }
    lazy var boundStreams: Streams = {
        var inputOrNil: InputStream? = nil
        var outputOrNil: OutputStream? = nil
        Stream.getBoundStreams(withBufferSize: 4096,
                               inputStream: &inputOrNil,
                               outputStream: &outputOrNil)
        guard let input = inputOrNil, let output = outputOrNil else {
            fatalError("On return of `getBoundStreams`, both `inputStream` and `outputStream` will contain non-nil streams.")
        }
        // configure and open output stream
        output.delegate = self
        output.schedule(in: .current, forMode: .default)
        output.open()
        return Streams(input: input, output: output)
    }()

  
    
    let session:Session = {
        let manager = ServerTrustManager(allHostsMustBeEvaluated:false,evaluators: ["192.168.5.3": DisabledTrustEvaluator()])
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 10
        let session = Session(configuration: configuration,serverTrustManager: manager)
        
        return  session
    }()
    
    

    override init() {
        super.init()
        contectSever()
        
    }
    
    func contectSever(){
//        var inputStream:InputStream?
//        var outputStream:OutputStream?
//        Stream.getBoundStreams(withBufferSize: 80000*16, inputStream: &inputStream, outputStream: &outputStream)
//        self.bodyStream = inputStream
//       
//        self.outputStream = outputStream
//        self.outputStream?.delegate = self
//        self.outputStream?.schedule(in: RunLoop.current, forMode: .common)
//        self.outputStream?.open()
        
//        boundStreams.input
       
        self.loadRequest = session.upload(boundStreams.input, to: "https://192.168.5.3:8000/dialogues", method: .post, headers: nil).uploadProgress { (progress) in
            // 上传进度
            print(self.alreadyRecord,progress.completedUnitCount)
            if self.isEnd && self.alreadyRecord == progress.completedUnitCount{
                self.stopTaskScaner()
                self.stopStream()
            }
            
        }.response(queue: DispatchQueue.main) { [weak self](PcmRespose) in
            
            if PcmRespose.error != nil{
                if self?.completion != nil {
                    self?.completion!(.failure(.netError))
                    debugPrint("上传失败")
                    MBProgressHUD.showError("请求失败,请重试", to: keywindow)
                }
            }
            if let data = PcmRespose.data{
                if let dic = JSON(data).dictionaryObject,let code = JSON(data)["code"].int{
                    switch code {
                    case code_succes:
                        if self?.completion != nil {
                            self?.completion!(.success(dic))
                            debugPrint("上传成功")
                        }
                        break
                    default:
                        if self?.completion != nil {
                            self?.completion!(.failure(.serverError(dic)))
                            debugPrint("上传失败")
                        }
                        MBProgressHUD.showError((dic["msg"] as? String) ?? "上传失败", to: keywindow)
                        break
                    }
                }else{
                    if self?.completion != nil {
                        self?.completion!(.failure(.netError))
                        debugPrint("上传失败")
                    }
                    MBProgressHUD.showError("请求失败,请重试", to: keywindow)
                }
            }
            
            self?.stopTaskScaner()
           
        }
        
        
        
        
//        DispatchQueue.main.asyncAfter(deadline: .now()+1, execute:{
            self.startTaskScaner()
//        })
        

    }
    
    func uploadData(_ data:Data){
 
        
        self.alreadyRecord += Int64(data.count)
        let task = PcmTask(data: data, hasUpload: false)
        self.dataTaskArr.append(task)
        print("上传长度：\(self.alreadyRecord)")

    }
    
    func endUpload(){
        
        self.isEnd = true
        print("结束")
    }
    
    func stopStream(){
        self.outputStream?.delegate = nil
        self.outputStream?.close()
    }
    
    deinit {
        self.stopTaskScaner()
    }

    
    private func startTaskScaner(){
        if timer == nil{
             self.timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) {
                       [weak self] timer in
                       guard let self = self else { return }

                       if self.canWrite {

                           if self.dataTaskArr.count != 0{
                               var task:PcmTask?
                               for (_,mytask) in self.dataTaskArr.enumerated(){
                                   if !mytask.hasUpload {
                                       task = mytask
                                   }
                               }
                               if task == nil{
                               }
                               if task != nil {

                                   guard let data = task?.data else {
                                       return
                                   }

                                   var buffer = [UInt8](repeating: 0, count: data.count)
                                   data.copyBytes(to: &buffer, count: data.count)

                                   let ret =  self.boundStreams.output.write(buffer, maxLength: data.count)
                                   print("写入\(ret),实际\(data.count)")
                                   if ret < data.count{

                                   }else{
                                       self.canWrite = false
                                       task?.hasUpload = true
                                   }
                               }
                           }
                       }
                   }
                   
            RunLoop.current.add(self.timer!, forMode: .common)

        }
    }
    
    
    func stopTaskScaner(){
        if (self.timer != nil) {
            self.timer?.invalidate()
            self.timer = nil
        }
    }

}

extension LXPcmUploader:StreamDelegate{
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
       
        guard aStream == boundStreams.output else {
                   return
               }
               if eventCode.contains(.hasSpaceAvailable) {
                   canWrite = true
               }
               if eventCode.contains(.errorOccurred) {
                   // Close the streams and alert the user that the upload failed.
               }

    }
}
