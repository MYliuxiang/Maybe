//
//  StreamPost.swift
//  MayBe
//
//  Created by liuxiang on 2020/6/24.
//  Copyright © 2020 liuxiang. All rights reserved.
//

import UIKit

public enum PostError:Swift.Error {
    
    case netError
    case serverError([String:Any])
}


public typealias PostCompletion = (_  reslut:Result<[String:Any],PostError>,_ created_on:String) -> Void

class StreamPost: NSObject {
    struct Streams {
        let input: InputStream
        let output: OutputStream
    }
    lazy var boundStreams: Streams = {
        var inputOrNil: InputStream? = nil
        var outputOrNil: OutputStream? = nil
        Stream.getBoundStreams(withBufferSize: 16000*16,
                               inputStream: &inputOrNil,
                               outputStream: &outputOrNil)
        guard let input = inputOrNil, let output = outputOrNil else {
            fatalError("On return of `getBoundStreams`, both `inputStream` and `outputStream` will contain non-nil streams.")
        }
        // configure and open output stream
        output.delegate = self
        output.schedule(in: .current, forMode: .default)
        output.open()
        return Streams(input: input, output: output)
    }()
    
    var dataTaskArr:[PcmTask] = [PcmTask]()
    var alreadyRecord:Int64 = 0
    var isEnd:Bool = false
    var completion:PostCompletion?
    var timer:Timer?
    var created_on:String!
    var cancleState = false
    var handleCancle:((_ created_on:String)->())?


    
    
    lazy var session: URLSession = URLSession(configuration: .default,
    delegate: self,
    delegateQueue: .main)
    
    var canWrite = false
    
    var responseData:Data = Data()
    
    var uploadTask:URLSessionUploadTask?

    
    convenience init(_ created_on:String) {
        self.init()
        self.created_on = created_on
        //192.168.5.3
        let url = URL(string: "https://52.163.48.60:8000/dialogues")!
        var request = URLRequest(url: url,
                                 cachePolicy: .reloadIgnoringLocalCacheData,
                                 timeoutInterval: 10)
        request.httpMethod = "POST"
        uploadTask = self.session.uploadTask(withStreamedRequest: request)
        uploadTask!.resume()
        
        
       
        self.timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) {
            [weak self] timer in
            guard let self = self else { return }

            if self.canWrite {

                if self.dataTaskArr.count != 0{
                    var task:PcmTask?
                    for (_,mytask) in self.dataTaskArr.enumerated(){
                        if !mytask.hasUpload {
                            task = mytask
                        }
                    }
                    if task == nil{
                    }
                    if task != nil {

                        guard let data = task?.data else {
                            return
                        }

                        var buffer = [UInt8](repeating: 0, count: data.count)
                        data.copyBytes(to: &buffer, count: data.count)

                        let ret =  self.boundStreams.output.write(buffer, maxLength: data.count)
                        print("写入\(ret),实际\(data.count)")
                        if ret < data.count{

                        }else{
                            self.canWrite = false
                            task?.hasUpload = true
                        }
                    }
                }
            }
        }
        
        RunLoop.current.add(self.timer!, forMode: .common)

    }
    
    func uploadData(_ data:Data){
    
           self.alreadyRecord += Int64(data.count)
           let task = PcmTask(data: data, hasUpload: false)
           self.dataTaskArr.append(task)
           print("upload",self.alreadyRecord)

    }
    
 
    
    
    func endUpload(){
        
        self.isEnd = true
        print(self.alreadyRecord)
        
    }
    
    func cancleLoad(){
        cancleState = true
        self.boundStreams.output.delegate = nil
        self.boundStreams.output.close()
        self.uploadTask?.cancel()
        self.stopTaskScaner()
    }
    
    func stopTaskScaner(){
           if (self.timer != nil) {
               self.timer?.invalidate()
               self.timer = nil
           }
       }

    deinit {
          self.stopTaskScaner()
          print("销毁了")
      }
   
    
   
}

extension StreamPost:StreamDelegate{
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        guard aStream == boundStreams.output else {
            return
        }
        if eventCode.contains(.hasSpaceAvailable) {
            canWrite = true
        }
        if eventCode.contains(.errorOccurred) {
            // Close the streams and alert the user that the upload failed.
        }
    }
    
}
extension StreamPost:URLSessionDataDelegate{
    
    func urlSession(_ session: URLSession, task: URLSessionTask,
                       needNewBodyStream completionHandler: @escaping (InputStream?) -> Void) {
           completionHandler(boundStreams.input)
       }
    
    //上传进度
    func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        print("StreamPost=>已上传：\(bytesSent),总上传:\(totalBytesSent)，期望上传:\(totalBytesExpectedToSend)")
        if self.isEnd && self.alreadyRecord == totalBytesSent{
            self.boundStreams.output.delegate = nil
            self.boundStreams.output.close()
            self.stopTaskScaner()

        }
        print("总长度\(self.alreadyRecord)")
    }
    
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        
        let protectionSpace = challenge.protectionSpace
        if protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust {
            let serverTrust = protectionSpace.serverTrust
            completionHandler(URLSession.AuthChallengeDisposition.useCredential, URLCredential(trust: serverTrust!))

        }else{
           completionHandler(URLSession.AuthChallengeDisposition.performDefaultHandling, nil);
        }
    }

    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void){
         completionHandler(.allow)
    }
    
       
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data){
        
         self.responseData.append(data)
        
    }

       
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, willCacheResponse proposedResponse: CachedURLResponse, completionHandler: @escaping (CachedURLResponse?) -> Void){
        
        guard self.responseData.count != 0 else{
            if self.completion != nil {
                self.completion!(.failure(.netError),self.created_on)
                debugPrint("上传失败")
            }
            MBProgressHUD.showError("请求失败,请重试", to: keywindow)
//            self.session.invalidateAndCancel()
            return
        }
                
        if let dic = JSON(self.responseData).dictionaryObject,let code = JSON(self.responseData)["code"].int{
                    switch code {
                    case code_succes:
                        if self.completion != nil {
                            self.completion!(.success(dic),self.created_on)
                            debugPrint("上传成功")
                        }
                        break
                    default:
                        if self.completion != nil {
                            self.completion!(.failure(.serverError(dic)),self.created_on)
                            debugPrint("上传失败")
                        }
                        MBProgressHUD.showError((dic["msg"] as? String) ?? "上传失败", to: keywindow)
                        break
                    }
                }else{
                    if self.completion != nil {
                        self.completion!(.failure(.netError),self.created_on)
                        debugPrint("上传失败")
                    }
                    MBProgressHUD.showError("请求失败,请重试", to: keywindow)
                }
//            self.session.invalidateAndCancel()

        
    }
    
   
    func urlSession(_ session: URLSession, task: URLSessionTask, didFinishCollecting metrics: URLSessionTaskMetrics){
        
        self.boundStreams.output.delegate = nil
        self.boundStreams.output.close()
        self.stopTaskScaner()
        
        
        print(task.state)
        if cancleState{
            if self.handleCancle != nil {
                self.handleCancle!(self.created_on)
            }
//            self.session.invalidateAndCancel()
            return
        }

        guard let transactionMetric = metrics.transactionMetrics.first else{
            if self.completion != nil {
                self.completion!(.failure(.netError),self.created_on)
                debugPrint("上传失败")
            }
            MBProgressHUD.showError("请求失败,请重试", to: keywindow)
            return
        }
        
        guard let respose = transactionMetric.response as? HTTPURLResponse else {
            if self.completion != nil {
                self.completion!(.failure(.netError),self.created_on)
                debugPrint("上传失败")
            }
            MBProgressHUD.showError("请求失败,请重试", to: keywindow)
//            self.session.invalidateAndCancel()

            return
        }
        
        if respose.statusCode == 200{

        }else{
            //上传失败
            if self.completion != nil {
                self.completion!(.failure(.netError),self.created_on)
                debugPrint("上传失败")
            }
            MBProgressHUD.showError("请求失败,请重试", to: keywindow)
        }
        
//        self.session.invalidateAndCancel()
        
    }

  
    
    
    
    
}
