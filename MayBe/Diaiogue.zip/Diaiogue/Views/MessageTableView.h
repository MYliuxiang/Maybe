//
//  MessageTableView.h
//  MyFamily
//
//  Created by 陆洋 on 15/6/9.
//  Copyright (c) 2015年 maili. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageTableView : UITableView

@property(nonatomic,assign) CGFloat lastOfferset;

@end
